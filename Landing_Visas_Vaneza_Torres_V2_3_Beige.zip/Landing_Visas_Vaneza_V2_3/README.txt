LANDING V2.3 — FONDO BEIGE + AZUL/DORADO

- Fondo beige neutro en toda la landing.
- Texto general negro/gris oscuro.
- Azul y dorado sólo para botones, iconos y resaltados.
- QR del bot grande en la primera pantalla junto al título.
- Animaciones al hacer scroll.
- Efecto de movimiento suave al pasar el mouse sobre QR y panel del bot.
- Tarjetas con elevación e interacción hover.
- Términos y condiciones adaptados al mismo estilo.
